package csss2013.util;

import org.graphstream.graph.Node;

public class Tools {
	public static double distance(Node n1, Node n2) {
		double lat1 = n1.getNumber("lat"), lat2 = n2.getNumber("lat"), lon1 = n1
				.getNumber("lon"), lon2 = n2.getNumber("lon");

		return distance(lat1, lon1, lat2, lon2);
	}

	public static double distance(double lat1, double lon1, double lat2,
			double lon2) {
		return orthodromie(lon1, lat1, lon2, lat2);
	}

	public static double orthodromie(double lat1, double lon1, double lat2,
			double lon2) {
		if (lat1 == lat2 && lon1 == lon2)
			return 0;

		lon1 = Math.toRadians(lon1);
		lon2 = Math.toRadians(lon2);
		lat1 = Math.toRadians(lat1);
		lat2 = Math.toRadians(lat2);

		double d = Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1)
				* Math.cos(lat2) * Math.cos(lon2 - lon1);
		d = 60 * Math.toDegrees(Math.acos(d));

		return 1852.0 * d;
	}
}

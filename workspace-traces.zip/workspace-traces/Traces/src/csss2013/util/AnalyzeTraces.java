package csss2013.util;

import java.io.IOException;

import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.AdjacencyListGraph;
import org.graphstream.stream.SinkAdapter;
import org.graphstream.stream.file.FileSourceDGS;

public class AnalyzeTraces extends SinkAdapter {
	public static final String TRACES_DGS = "export/output.dgs";

	FileSourceDGS dgs;
	Graph g;
	long tick = 50;

	public AnalyzeTraces() {
		dgs = new FileSourceDGS();
		g = new AdjacencyListGraph("traces");

		dgs.addSink(g);
		g.addSink(this);

		try {
			dgs.begin(TRACES_DGS);
		} catch (IOException e) {
			e.printStackTrace();
		}

		g.display(false);
	}

	public void analyze() {
		//
		// TODO ....
		//
	}

	public void run() {
		while (next()) {
			try {
				if (tick > 0)
					Thread.sleep(tick);
			} catch (InterruptedException e) {
			}
		}
	}

	public boolean next() {
		try {
			return dgs.nextStep();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.graphstream.stream.SinkAdapter#stepBegins(java.lang.String,
	 * long, double)
	 */
	public void stepBegins(String sourceId, long timeId, double step) {
		analyze();
	}

	public static void main(String... args) {
		AnalyzeTraces a = new AnalyzeTraces();
		a.run();
	}
}
